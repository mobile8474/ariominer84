//
// Created by Haifa Bogdan Adnan on 04/08/2018.
//

#ifndef ARIOMINER_CONFIG_H_IN_H
#define ARIOMINER_CONFIG_H_IN_H

#define ArioMiner_VERSION_MAJOR "0"
#define ArioMiner_VERSION_MINOR "2"
#define ArioMiner_VERSION_REVISION "0"

#endif //ARIOMINER_CONFIG_H_IN_H
